"""
Makes stationprocessing a module
"""
