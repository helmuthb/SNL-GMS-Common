"""
Makes provenance a module
"""
