"""
Makes data acquisition a module
"""
