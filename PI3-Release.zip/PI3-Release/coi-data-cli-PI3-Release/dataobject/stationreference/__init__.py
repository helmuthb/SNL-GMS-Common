"""
Makes stationreference a module
"""
