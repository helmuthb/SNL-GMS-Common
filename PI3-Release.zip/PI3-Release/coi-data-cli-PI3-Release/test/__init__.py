"""
Makes test a module
"""
