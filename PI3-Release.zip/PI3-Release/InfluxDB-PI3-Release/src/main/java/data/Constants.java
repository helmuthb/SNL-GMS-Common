package data;

/**
 * Created by jwvicke on 11/30/17.
 */
public class Constants {

    public static final int[] TEST_SIZES
            = new int[] {500, 2500, 25000, 250000, 500000, 1000000, 2000000};
}
