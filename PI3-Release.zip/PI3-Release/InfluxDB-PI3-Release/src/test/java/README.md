temporary file in order to properly commit folder structure
