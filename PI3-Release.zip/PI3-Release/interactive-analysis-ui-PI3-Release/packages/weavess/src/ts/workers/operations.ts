export const WorkerOperations = {
    CREATE_POSITION_BUFFER: 'createPositionBuffer',
    CREATE_RECORD_SECTION_POSITION_BUFFER: 'createRecordSectionPositionBuffer'
};
