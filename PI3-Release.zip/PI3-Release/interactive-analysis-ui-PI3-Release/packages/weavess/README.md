# WEAVESS: Web-Enhanced Application for the Viewing and Exploitation of Sensor Samples

WEAVESS is a JavaScript library for high-performance display of waveform data. It is currently in super-alpha, and only supports very limited functionality.

# Documentation

See the [examples](examples) directory for example usage. 
