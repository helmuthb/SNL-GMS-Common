# Examples

if this project is cloned or downloaded, these examples can be loaded as files in the browser. Otherwise, peruse the source code for ideas on how to use WEAVESS in various ways.

## Documentation

Currently, no formal API Docs exist. Hopefully they will be coming soon. For now, these examples and the source code are your only hope. 
