// const WeavessWorker = require('worker-loader?inline&fallback=false!../packages/weavess/src/ts/workers'); // tslint:disable-line

// Import this named export into your test file:
/* export const mockWeavessWorker = jest.fn();
export const mock = jest.fn().mockImplementation(() =>
  ({
      WeavessWorker: mockWeavessWorker
    }));
 */