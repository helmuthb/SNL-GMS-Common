Analysis display core codebase.

## Development

To build the node application

```bash
[.../analyst-ui-core] $ npm run build
```

To start a development server hosting the analysis UI

```bash
[.../analyst-ui-core] $ npm start
```

Then, access `http://localhost:8080` in your browser, or run [../analyst-ui-electron](../analyst-ui-electron) to access the native version of the analysis UI
