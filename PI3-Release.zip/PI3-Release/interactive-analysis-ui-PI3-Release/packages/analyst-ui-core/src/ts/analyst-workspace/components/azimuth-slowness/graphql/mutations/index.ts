export { CreateFkInput, createFkMutation } from './create-fk';
export { UpdateAzSlowFkInput, updateAzSlowFromFkMutation } from './update-az-slow-fk';
