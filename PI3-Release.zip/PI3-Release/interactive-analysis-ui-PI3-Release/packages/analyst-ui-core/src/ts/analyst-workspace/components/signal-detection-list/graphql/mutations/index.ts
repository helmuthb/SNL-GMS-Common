export { UpdateDetectionsInput, updateDetectionsMutation } from './update-detections';
