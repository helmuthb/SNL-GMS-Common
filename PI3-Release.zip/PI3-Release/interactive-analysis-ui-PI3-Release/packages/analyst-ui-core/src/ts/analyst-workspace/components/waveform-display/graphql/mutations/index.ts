export { createDetectionMutation, CreateDetectionInput } from './create-detection';
export { updateDetectionsMutation, UpdateDetectionsInput } from './update-detections';
export { rejectDetections, RejectDetectionsInput } from './reject-detections';
