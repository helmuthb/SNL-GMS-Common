export { createStore } from './analyst-workspace/apollo-redux/create-store';
