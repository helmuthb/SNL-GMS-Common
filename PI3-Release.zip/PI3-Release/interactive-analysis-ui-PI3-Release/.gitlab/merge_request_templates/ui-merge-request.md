> *Have you updated the VERSION? Have you updated the CHANGELOG?*

## Description
### Issue
### Solution
### Jazz 

## Documentation
### Building
  ```bash
  [ .../interactive_analysis_ui] $ npm install
  [ .../interactive_analysis_ui] $ npm run bootstrap
  [ .../interactive_analysis_ui] $ npm run build
  ```
### Running
  `npm start`
### Test
  `npm test`
  
## Breaking Changes / Known Issues