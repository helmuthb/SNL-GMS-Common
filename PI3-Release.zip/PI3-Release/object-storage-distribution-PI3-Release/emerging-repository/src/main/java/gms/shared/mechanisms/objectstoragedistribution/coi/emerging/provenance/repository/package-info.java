/**
 * Contains GMS Provenance persistence interfaces and implementations.
 */
package gms.shared.mechanisms.objectstoragedistribution.coi.emerging.provenance.repository;