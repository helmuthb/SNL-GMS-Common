/**
 * Contains the GMS implementations of the COI data objects related to processing sequence
 * definition and control.
 */
package gms.shared.mechanisms.objectstoragedistribution.coi.emerging.processingcontrol.commonobjects;