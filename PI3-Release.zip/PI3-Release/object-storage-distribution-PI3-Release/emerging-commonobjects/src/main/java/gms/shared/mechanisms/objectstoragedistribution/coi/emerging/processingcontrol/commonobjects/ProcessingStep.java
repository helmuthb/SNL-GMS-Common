package gms.shared.mechanisms.objectstoragedistribution.coi.emerging.processingcontrol.commonobjects;

public class ProcessingStep {
  // TODO: Develop class. This is just a placeholder created when working on ProcessingContext.
}
