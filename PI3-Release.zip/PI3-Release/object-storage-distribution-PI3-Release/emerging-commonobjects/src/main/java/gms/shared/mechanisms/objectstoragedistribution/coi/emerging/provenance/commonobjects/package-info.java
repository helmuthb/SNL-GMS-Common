/**
 * Contains GMS implementations of the provenance COI data objects.
 */
package gms.shared.mechanisms.objectstoragedistribution.coi.emerging.provenance.commonobjects;