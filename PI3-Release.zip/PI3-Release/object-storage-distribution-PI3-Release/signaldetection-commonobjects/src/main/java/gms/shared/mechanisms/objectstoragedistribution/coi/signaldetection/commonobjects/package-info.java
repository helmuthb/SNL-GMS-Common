/**
 * Contains GMS implementations of the Station Reference COI data objects.
 */
package gms.shared.mechanisms.objectstoragedistribution.coi.signaldetection.commonobjects;