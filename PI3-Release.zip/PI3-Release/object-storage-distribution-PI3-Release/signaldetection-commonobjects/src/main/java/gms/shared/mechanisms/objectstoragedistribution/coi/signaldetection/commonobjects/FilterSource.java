package gms.shared.mechanisms.objectstoragedistribution.coi.signaldetection.commonobjects;

/**
 * Describes the source of a {@link FilterDefinition}
 */
public enum FilterSource {
  SYSTEM,
  USER
}
