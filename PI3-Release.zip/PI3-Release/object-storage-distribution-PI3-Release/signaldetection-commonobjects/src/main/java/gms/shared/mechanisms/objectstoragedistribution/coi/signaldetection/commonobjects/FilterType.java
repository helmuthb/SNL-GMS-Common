package gms.shared.mechanisms.objectstoragedistribution.coi.signaldetection.commonobjects;

/**
 * Defines types for {@link FilterDefinition}
 */
public enum FilterType {
  FIR_HAMMING,
  IIR_BUTTERWORTH
}
