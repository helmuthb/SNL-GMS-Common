object-storage-distribution

To build JavaDocs:

1) cd object-storage-distribution
2) javadoc -d ./docs/html -overview ./src/overview.html -sourcepath ./src/main/java -subpackages gms


