/**
 * Contains an algorithm and associated data objects for creating QcMasks from acquired channel
 * state-of-health information.
 */
package gms.core.waveformqc.channelsohqc.algorithm;