# channel-soh-qc project

Contains a plugin creating waveform QC masks based on acquired channel state-of-health information.